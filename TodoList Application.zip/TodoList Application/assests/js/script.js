const input = document.querySelector("input")
const addBtn = document.querySelector(".add-btn")
const removeBtn = document.querySelector(".remove-btn")
const todoTask = document.querySelector(".todoTask")
const savebtn= document.querySelector(".save-btn")
const deleteAll = document.querySelector(".remove-btn")
const editButton = document.querySelector(".Edit-task")

///.................................


// ////Creating P
// const p = document.createElement("p")
// //Delete Button
// const deleteBtn = document.createElement("a")
// deleteBtn.href="#"
// deleteBtn.textContent="Delete"
// deleteBtn.classList.add("deletebtn")
//Edit Button

const editBtn = document.createElement("a")
editBtn.href="#"
editBtn.textContent="Edit"
editBtn.classList.add("editbtn")

//................Globel Variable
let editTodo = null
//.............................................
function todoList(){


    if(input.value<=0){
        alert("Enter Your Task")
        return false
    }
    // if(addBtn.textContent==="Edit Todo"){
    //     editTodo.target.previousElementSibling.textContent= input.value
    //     input.value=""
    //  }
    else{
        // const todoTaskList = document.createElement("div")
        // todoTaskList.classList.add("todoTaskList")
        // p.textContent= input.value
        // todoTaskList.appendChild(p.cloneNode(true))
        // todoTaskList.appendChild(editBtn)
        // todoTaskList.appendChild(deleteBtn)
        // todoTask.appendChild(todoTaskList.cloneNode(true))
        let localTodo = JSON.parse(localStorage.getItem("datoData")) || []
        localTodo.push(input.value)
        localStorage.setItem("datoData", JSON.stringify(localTodo))
        console.log(localTodo)
        
        input.value=""
        displayList()
        
       
      
    }
   
   
    


}
// const updateTOdo = (e)=>{
    
//     if(e.target.textContent==="Delete"){
//         // let localTodo = JSON.parse(localStorage.getItem("datoData")) || []
        
//         e.target.parentElement.remove()
//      }
//      if(e.target.textContent==="Edit"){
        
//        input.value = e.target.previousElementSibling.textContent
//        input.focus()
//        addBtn.textContent="Edit Todo"
//        editTodo= e
       
//     }
// }

//...........................

addBtn.addEventListener("click",(e)=>{
    
e.preventDefault()
displayList()
    todoList()
   
})


//.......................Edit and Delete

// todoTask.addEventListener("click",updateTOdo)

const  listDelete = (index)=>{
    let localTodo = JSON.parse(localStorage.getItem("datoData")) || []
    localTodo.splice(index,1)
    localStorage.setItem("datoData", JSON.stringify(localTodo))
    displayList()
}
//......Edit
const listEdit = (index)=>{
    let localTodo = JSON.parse(localStorage.getItem("datoData")) || []
    console.log(localTodo[index])
    input.value= localTodo[index]
    addBtn.style.display="none"
    editButton.style.display="block"
    debugger
    editButton.addEventListener("click",(e)=>{
       
        let localTodo = JSON.parse(localStorage.getItem("datoData")) || []
       
       
      localTodo[index] = input.value
      
       localStorage.setItem("datoData", JSON.stringify(localTodo))
      
       displayList()
     
   
       addBtn.style.display="block"
       editButton.style.display="none"
       input.value=""
     
         
    })
    
}

const displayList = ()=>{
    let localTodo = JSON.parse(localStorage.getItem("datoData")) || []
    let displayData = ""
   localTodo.forEach((element, index) => {
    
    displayData+=` <div class="todoTaskList">
    <div class="todoText">
    <span>${index+1})</span>
    <p>${element}</p>
    </div>
   
   <div class="toddobuttons">
   <a href="#" onclick = "listDelete(${index})" class="deletebtn">Delete</a>
    <a href="#" onclick= "listEdit(${index})"  class="editbtn">Edit</a>   
   </div>
    
     
</div>`
   });
   todoTask.innerHTML= displayData
}

displayList()
// if(e.target.textContent==="Edit")
// input.value= e.target.previousElementSibling.textContent
// input.focus()
// addBtn.textContent="Edit Task"
// editTodo= e

//........ Delete All 
const deletAllData = ()=>{
    // let localTodo = JSON.parse(localStorage.getItem("datoData")) || []
    localStorage.removeItem("datoData")
    
}
deleteAll.addEventListener("click", ()=>{

    deletAllData()
})

